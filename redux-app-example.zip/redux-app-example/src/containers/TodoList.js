import React from 'react';
import Todo  from './../components/Todo.js';
import { toggleTodo } from '../actions/TodoAction';
import { VisibilityFilters } from '../constants/VisibilityType';
import { connect } from 'react-redux';

const TodoList = ({ todos, toggleTodo }) => (
  <ul>
    {todos.map(todo => 
      <Todo key={todo.id} {...todo} onClick={() => toggleTodo(todo.id)} /> 
    )}
  </ul>
)

const mapStateToProps = (state) =>{
  return {
    todos: getVisibleTodos(state.todosReducer, state.visibilityFilterReducer)
  }
}
const getVisibleTodos = (todos, filter) => {
  switch (filter) {
    case VisibilityFilters.SHOW_ALL:
      return todos
    case VisibilityFilters.SHOW_COMPLETED:
      return todos.filter(t => t.completed)
    case VisibilityFilters.SHOW_ACTIVE:
      return todos.filter(t => !t.completed)
    default:
      throw new Error('Unknown filter: ' + filter)
  }
}

const mapDispatchToProps = (dispatch) => {
  return {
    toggleTodo: (id) => dispatch(toggleTodo(id))
  }
}

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(TodoList)
