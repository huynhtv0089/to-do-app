import { combineReducers } from 'redux';
import todosReducer from './TodosReducer';
import visibilityFilterReducer from './VisibilityFilterReducer';

export default combineReducers({
  todosReducer,
  visibilityFilterReducer
})
