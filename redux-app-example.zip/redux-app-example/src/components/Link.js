import React from 'react';

const Link = ({ active, children, onClick }) => {
  console.log('active: ' + active);
  console.log('children: ' + children);
  console.log('onClick: ' + onClick);
  return (
    <button onClick={onClick} disabled={active} style={{ marginLeft: '4px',}}>
      {children}
    </button>
  )
}

export default Link
