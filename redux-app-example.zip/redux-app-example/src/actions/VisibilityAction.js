export const setVisibilityFilterAction = filter => ({
    type: 'SET_VISIBILITY_FILTER',
    filter
})