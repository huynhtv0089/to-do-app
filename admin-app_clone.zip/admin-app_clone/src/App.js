import React from 'react';
import {BrowserRouter as Router, Route} from 'react-router-dom';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';

import Header from './components/layout/Header';
import Sidebar from './components/layout/Sidebar';

import Dashboard from './components/pages/Dashboard';
import Users from './components/pages/Users';

function App() {
  return (
    <Router>
      <Header />

      <div className="container-fluid">
        <div className="row">
          <Sidebar />

          <Route path="/dashboard" component={Dashboard} />
          <Route path="/users" component={Users} />
        </div>
      </div>
    </Router>
  );
}

export default App;
