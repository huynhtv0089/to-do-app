import React, {useState} from 'react';
import Modal  from 'react-bootstrap/Modal';

export default class Users extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            isShowModal: false,
            titleModal: 'Create a user'
        };

        console.log(this.state);
    }

    toggleModal(isCreateUser) {
        this.setState({
            isShowModal: true,
            titleModal: (isCreateUser ? 'Create a user' : 'Update user')
        });
    }

    closeModal() {
        this.setState({
            isShowModal: !this.state.isShowModal
        });
    }

    onSaveUser(user) {
        console.log(user);
    }

    render() {
        return (
            <main className="col-md-9 ml-sm-auto col-lg-10 px-md-4">
                <div className="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 className="h2">Users</h1>
                    <div className="btn-toolbar mb-2 mb-md-0">
                        <button className="btn btn-primary" onClick={this.toggleModal.bind(this, true)}>
                            Add User
                        </button>
                    </div>
                </div>

                <div className="table-responsive">
                    <table className="table table-striped table-sm">
                        <thead>
                            <tr>
                                <th>Email</th>
                                <th>Fullname</th>
                                <th>Address</th>
                                <th className="text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>schmidtJose@gmail.com</td>
                                <td>Ava Schaden</td>
                                <td>2128 Bernhard Trafficway Suite 920 North Gabe, AK 97881-3406</td>
                                <td>
                                    <button className="btn btn-link text-warning" onClick={this.toggleModal.bind(this, false)}>Edit</button>
                                    <button className="btn btn-link text-danger">Delete</button>
                                </td>
                            </tr>
                            <tr>
                                <td>vaughn06@yahoo.com</td>
                                <td>Dr. Darren O'Connell</td>
                                <td>5743 Pacocha Rapids Apt. 943 Dylanton, IN 01699-0839</td>
                                <td>
                                    <button className="btn btn-link text-warning" onClick={this.toggleModal.bind(this, false)}>Edit</button>
                                    <button className="btn btn-link text-danger">Delete</button>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>

                <ModalSaveUser  isShow={this.state.isShowModal} 
                                onClose={this.closeModal.bind(this)}
                                title={this.state.titleModal}
                                saveUser={this.onSaveUser.bind(this)} />
            </main>
        );
    }
}

function ModalSaveUser(props) {

    const [user, changeUserData] = useState({
        "email": "",
        "firstName": "",
        "lastName": "",
        "address": ""
    })

    const getUserData = (e) => {
        switch(e.target.name) {
            case 'email':
                user.email = e.target.value;
                break;
            case 'firstName':
                user.firstName = e.target.value;
                break;
            case 'lastName':
                user.lastName = e.target.value;
                break;
            case 'address':
                user.address = e.target.value;
                break;
        }

        return changeUserData(user);
    }

    const passUserData = () => {
        props.saveUser(user);
        props.onClose();
    }

    return (
        <Modal show={props.isShow} onHide={props.onClose}>
            <Modal.Header closeButton>
                <Modal.Title>{props.title}</Modal.Title>
            </Modal.Header>

            <Modal.Body>
                <form>
                    <div className="form-group">
                        <label htmlFor="txtEmail">Email</label>
                        <input type="email" className="form-control" 
                                id="txtEmail" name="email" 
                                onChange={getUserData} />
                    </div>
                    
                    <div className="form-group">
                        <label htmlFor="txtFirstName">First name</label>
                        <input type="text" className="form-control" 
                                id="txtFirstName" name="firstName" 
                                onChange={getUserData} />
                    </div>

                    <div className="form-group">
                        <label htmlFor="txtLastName">Last name</label>
                        <input type="text" className="form-control" 
                                id="txtLastName" name="lastName" 
                                onChange={getUserData} />
                    </div>

                    <div className="form-group">
                        <label htmlFor="txtAddress">Address</label>
                        <textarea className="form-control" id="txtAddress" 
                                    name="address" rows="3" 
                                    onChange={getUserData}></textarea>
                    </div>
                </form>
            </Modal.Body>

            <Modal.Footer>
                <button className="btn btn-secondary" onClick={props.onClose}>
                    Close
                </button>
                <button className="btn btn-primary" onClick={passUserData}>
                    Save Changes
                </button>
            </Modal.Footer>
        </Modal>
    );
}

